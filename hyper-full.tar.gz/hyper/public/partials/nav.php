<header class="site-header">
  <div class="container nav-container">
    <a href="/" class="brand">HYPER</a>
    <nav class="nav">
      <a href="/products.php">Products</a>
      <a href="/events.php">Events</a>
      <a href="/athletes.php">Athletes</a>
      <a href="/stories.php">Stories</a>
    </nav>
    <button class="nav-toggle" aria-label="Toggle navigation">☰</button>
  </div>
</header>